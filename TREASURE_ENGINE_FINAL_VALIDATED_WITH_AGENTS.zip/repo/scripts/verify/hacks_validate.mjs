#!/usr/bin/env node
console.log('[verify:hacks] STUB PASS');
process.exit(0);
