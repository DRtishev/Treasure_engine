#!/usr/bin/env node
console.log('[court_stub] Not needed for E2.1, skipping');
process.exit(0);
