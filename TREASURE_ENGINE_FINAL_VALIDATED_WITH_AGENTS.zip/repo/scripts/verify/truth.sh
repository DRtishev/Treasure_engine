#!/bin/bash
echo "[verify:truth] STUB PASS"
exit 0
